AP Assignment 2
Chahat Ahuja
2022138
_________________________________________________________________________________________
-I have made the following assumptions
-I have used array lists and added samples values in the which are self-made or are taken from Chatgpt.
•	One for visitor
•	3 for attractions
•	2 discounts(GIVEN)
•	2 special discounts(GIVEN)
- Here are the Admin login details:
•	The admin id: admin123
•	The admin pass: c-a-2
-The getters and setters have been properly implemented and used in the code 
-One interface named “MakeSound” is made
-The initial value of total visitors has been set to 10 and total revenue is 1000
•	The value of total visitors increases when a visitor is registered or logged in.
•	The total revenue increases when a ticket or membership is purchased.
-There is one visitor already with username “chahat” and password “chahat”
_________________________________________________________________________________________

For running the program perform the following steps: 
1. mvn clean 
2. mvn compile
3. mvn package
4. java -jar target/AP_2_Chahat-1.0-SNAPSHOT

