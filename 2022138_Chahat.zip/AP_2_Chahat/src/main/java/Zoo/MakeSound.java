package Zoo;

public interface MakeSound {
    public String sound();
}
